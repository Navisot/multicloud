#!/bin/bash
#sudo rm -rf /home/ubuntu/application
