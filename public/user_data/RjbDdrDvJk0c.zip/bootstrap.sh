#!/usr/bin/env bash
cd /home/ubuntu/application/
sudo docker-compose down
sudo docker-compose up -d
sudo service codedeploy-agent start
