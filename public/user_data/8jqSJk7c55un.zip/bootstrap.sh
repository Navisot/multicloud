#!/usr/bin/env bash

sudo docker-compose -f /home/ubuntu/application/docker-compose.yml up -d

sudo service codedeploy-agent start
