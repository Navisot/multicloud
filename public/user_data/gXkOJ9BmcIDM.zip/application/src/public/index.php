<?php

echo 'HELLO - AWS Dockerized Image - It Works!';

?>
