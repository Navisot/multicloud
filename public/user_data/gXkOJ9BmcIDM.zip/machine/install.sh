#!/bin/bash
cd /home/ubuntu/application
sudo docker-compose up -d
