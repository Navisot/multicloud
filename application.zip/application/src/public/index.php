<?php

echo 'Azure Deployment';

?>
